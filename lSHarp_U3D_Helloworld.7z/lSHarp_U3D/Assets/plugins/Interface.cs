﻿using UnityEngine;
using System.Collections;

public static class Interface 
{

	public static void Test1()
	{
		Debug.Log ("这是真的");
	}
	public static void Test2()
	{
		Debug.Log ("这不是梦");
	}
}