﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace HotFixCode
{
    public class TestClass
    {
        public static void Test1()
        {
            Interface.Test1();
        }
        public int count = 0;
        public void Test2()
        {
            count++;
            Interface.Test2();
        }
        public void Test2(int abc, string def)
        {
            count++;
            UnityEngine.Debug.Log("这不是梦 2.0," + abc + "," + def + ",count=" + count);
        }
    }
}
