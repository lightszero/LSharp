﻿using System;
using System.Collections.Generic;
using System.Text;

namespace testdll01
{
    public class Class1
    {
    }
}
