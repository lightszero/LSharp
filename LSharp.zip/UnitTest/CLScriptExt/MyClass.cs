﻿using System;
using System.Collections.Generic;

using System.Reflection.Emit;
using System.Text;



public class MyClass2
{

}
public class config
{
    public static int Cell(double i)
    {
        return (int)i;
    }
}

