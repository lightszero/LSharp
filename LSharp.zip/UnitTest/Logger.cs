﻿using System;
using System.Collections.Generic;
using System.Text;

namespace UnitTest
{
    public class Logger
    {
        public static void Log(string str)
        {
            Form1.g_this.Log(str);
        }

    }
}
